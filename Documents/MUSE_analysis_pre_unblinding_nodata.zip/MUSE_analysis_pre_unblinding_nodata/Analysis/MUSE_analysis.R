##*****************************************##
## Analysis of MUSE-SAP study            ####
## James Liley                             ##
## 26 October 2022                         ##
##*****************************************##
## 
## Please note that this pipeline assumes that the raw data file is saved without a password.
## 

##*****************************************##
## Packages and scripts                  ####
##*****************************************##

# Packags
library(lme4) # Linear mixed models
library(readxl) # Read excel files

# Main functions
source("Analysis/MUSE_functions.R")


# Directories
raw_data_dir="./Data/Raw/" # Look for raw data CSV in this folder
working_data_dir="./Data/Working/" # Save working data to this folder
save_dir="./Analysis/Results/Figures/" # Directory to which figures are saved
text_dir="./Analysis/Results/output.txt" # Specify to write output to a text file; otherwise written to console

# Switches and options: general
recheck_conf_int=FALSE # Set to TRUE to redo a simulation to verify confidence interval cover. If FALSE, will check if a simulation has already been performed and saved.
redo_power_calculation=FALSE # Set to TRUE to do a power calculation for a given estimated effect size. If FALSE, will check if one has already been performed and saved.
alpha=0.05 # Type 1 error rate for confidence intervals/sample size calculations
beta=0.1 # Type 2 error rate for sample size calculations
ndig=4 # Number of significant figures for outputs
npower=1000 # Number of simulations at each sample size for power calculations

# Switches and options - specific
sf36_use_uk=TRUE # Set to TRUE to use UK data to generate MCS and PCS for SF36; otherwise use US
sf36_use_z=FALSE # Set to TRUE to express SF36 MCS and PCS as Z scores; FALSE to use T scores, where T=10Z + 50.

# Setup
if (!is.null(text_dir)) sink(text_dir)
cat("Starting...\n\n")

# Print R and package versions

cat("R session info:\n\n")
print(sessionInfo())

cat("\n\n\n")



##*****************************************##
## Read data                             ####
##*****************************************##

# Main MUSE data: three sheets
mfile=paste0(raw_data_dir,"19 October 22 MUSE FEP combined data.xlsx")
muse_baseline=suppressMessages(read_xlsx(mfile,sheet=1))
muse_8week=suppressMessages(read_xlsx(mfile,sheet=2))
muse_12week=suppressMessages(read_xlsx(mfile,sheet=3))
muse_raw=list(muse_baseline,muse_8week,muse_12week)

# Data on number of modes of hallucination
modefile=paste0(raw_data_dir,"number of modalities.xlsx")
modes_raw= suppressMessages(read_xlsx(modefile))

cat("Loaded data\n\n")

# SF36 mean scores in various populations, used for SF36 processing
sf36file=paste0(raw_data_dir,"sf36_distributions.csv")
sf36_dist= suppressMessages(read.csv(sf36file,row.names=1))
if (sf36_use_uk) pref="UK_" else pref="US_"
sf36_dist=sf36_dist[,grep(pref,colnames(sf36_dist))]
colnames(sf36_dist)=gsub(pref,"",colnames(sf36_dist))


##*****************************************##
## Basic processing                      ####
##*****************************************##

muse=list()
for (i in 1:length(muse_raw)) {
  
  ## Get data for corresponding time point
  dat=muse_raw[[i]]
  
  ## Rename columns
  dnames=make.names(muse_raw[[1]][1,])
  col_names=c("site","id","group",
              NA,paste0("psyrats_voices_",dnames[5:15]),"psyrats_voices_total",rep(NA,4),
              NA,paste0("psyrats_delusions_",dnames[22:27]),"psyrats_delusions_total",
              paste0("hpsvq_",dnames[29:37]),"hpsvq_total",NA,
              paste0("dass21_",dnames[40:60]),"dass21_total",NA,NA,NA,
              NA,paste0("choice_",dnames[66:89]),
                NA,paste0("choice_",dnames[90],"_how_do_you_feel"),
                NA,paste0("choice_",dnames[92],"_how_do_you_feel"),NA,
                paste0("choice_",dnames[95:118]),
                NA,paste0("choice_",dnames[119],"_how_satisfied"),
                NA,paste0("choice_",dnames[121],"_how_satisfied"),
              paste0("qpr_",dnames[123:137]),"qpr_total",
              paste0("sf36_",dnames[139:140]),NA,
                paste0("sf36_",dnames[142:151]),NA,              
                paste0("sf36_",dnames[153:156]),NA,
                paste0("sf36_",dnames[158:173]),NA,
                paste0("sf36_",dnames[175:178]),"sf36_total",
              paste0("eq5d_",dnames[180:185]),"eq5d_total",
              paste0("icecap_",dnames[187:191]),"icecap_total")
  if (i %in% 2:3) col_names=col_names[-c(3,17:20,39,62:64)]
  
  colnames(dat)=col_names
    
  ## Remove unnecessary rows
  if (i==1) dat=dat[3:dim(dat)[1],] else dat=dat[2:dim(dat)[1],]
  
  ## Remove unnecessary columns
  dat=dat[,which(!is.na(colnames(dat)))]
  
  ## Convert to data frame
  dat=as.data.frame(dat)
  
  ## Convert all columns to integers
  for (j in 1:dim(dat)[2]) dat[,j]=suppressWarnings(as.numeric(gsub("[^0-9.-]", "", dat[,j])))

  ## Convert 999s etc to NA
  for (j in 1:dim(dat)[2]) dat[which(dat[,j]>998),j]=NA
  
    
  ## Save
  muse[[i]]=dat
}
names(muse)=names(muse_raw)


## Modalities data: affix to main table
modes=as.data.frame(modes_raw[3:84,c(1,2,4,8,11)])
colnames(modes)=c("site","id","modes_baseline","modes_8week","modes_12week")
modes$id=as.numeric(modes$id)
# correct typos
auditory=c("Auditory", "Aufitory", "Auditrory", "Auditry")
visual=c("Visual", "visual")
somatic=c("Somatic", "somatic",  "soamtic")
olfactory=c("Olfactory", "olfactory", "oflactory")
felt_presence=c("Felt presence","Felt sense", "felt presence", 
                "Felt Presence", "felt sense", "fet presence", "felt oresence")
mode_missing=c("999")
for (i in 1:3) {
  mtab=muse[[i]]
  m=match(modes$id,mtab$id)
  mtab$modality_auditory[m]=anygrepl(auditory,modes[[i+2]],miss=mode_missing)
  mtab$modality_visual[m]=anygrepl(visual,modes[[i+2]],miss=mode_missing)
  mtab$modality_somatic[m]=anygrepl(somatic,modes[[i+2]],miss=mode_missing)
  mtab$modality_olfactory[m]=anygrepl(olfactory,modes[[i+2]],miss=mode_missing)
  mtab$modality_felt_presence[m]=anygrepl(felt_presence,modes[[i+2]],miss=mode_missing)
  muse[[i]]=mtab
}



##*****************************************##
## Collate questionnaires                ####
##*****************************************##

muse_summary=list()
for (i in 1:length(muse)) { # Loop over times
  dat0=muse[[i]]
  if (i==1) dat=dat0[,1:3] else dat=dat0[,1:2]
  
  ## PSYRATS scores
  psyrats = dat0[,grep("psyrats_",colnames(dat0))]
  dat$psyrats_hdis=rsm(psyrats[,c(6,7,8,9,11)])
  dat$psyrats_hfreq=rsm(psyrats[,c(1,2,10)])
  dat$psyrats_hattrcog=rsm(psyrats[,c(3,5)])
  dat$psyrats_hloud=psyrats[,4]
  dat$psyrats_voices_total=rsm(psyrats[,1:11]) # Recalculate this
  dat$psyrats_delusions_total=rsm(psyrats[,13:18]) # Recalculate this
  dat$psyrats_total=rsm(psyrats[,c(1:11,13:18)])
  
  ## HPSVQ scores
  hpsvq = dat0[,grep("hpsvq",colnames(dat0))]
  dat$hpsvq_total = rsm(hpsvq[,c(1:9)]) # Recalculate
  dat$hpsvq_negative = rsm(hpsvq[,c(2,5,6,7)])
  
  ## DASS21 scores
  dass21 = dat0[,grep("dass21",colnames(dat0))]
  dat$dass21_total = rsm(dass21[,c(1:21)]) # Recalculate
  dat$dass21_stress = rsm(dass21[,c(1,6,8,11,12,14,18)])
  dat$dass21_anxiety = rsm(dass21[,c(2,4,7,9,15,19,20)])
  dat$dass21_depression = rsm(dass21[,c(3,5,10,13,16,17,21)])
  
  ## CHOICEs scores  
  choice = dat0[,grep("choice_",colnames(dat0))]
  dat$choice_short_total = rsm(choice[,c(1, 2, 3, 7, 9, 12, 17, 18, 20, 21, 22)])
  
  ## QPR scores
  qpr = dat0[,grep("qpr_",colnames(dat0))]
  dat$qpr_total = rsm(qpr[,1:15])
  
  ## SF36 scores
  sf36 = dat0[,grep("sf36_",colnames(dat0))]
  for (r in c(1, 2, 20, 22, 34, 36)) sf36[,r] = c(100,75,50,25,0)[sf36[,r]]
  for (r in c(3, 4, 5, 6, 7, 8, 9, 10, 11, 12)) sf36[,r] = c(0,50,100)[sf36[,r]]
  for (r in c(13, 14, 15, 16, 17, 18, 19)) sf36[,r] = c(0,100)[sf36[,r]]
  for (r in c(21, 23, 26, 27, 30)) sf36[,r] = c(100,80,60,40,20,0)[sf36[,r]]
  for (r in c(24, 25, 28, 29, 31)) sf36[,r] = c(0,20,40,60,80,100)[sf36[,r]]
  for (r in c(32, 33, 35)) sf36[,r] = c(0,25,50,75,100)[sf36[,r]]
  dat$sf36_PF_physical = rsm(sf36[,c(3, 4, 5, 6, 7, 8, 9, 10, 11, 12)],sf36=TRUE)
  dat$sf36_RP_role_physical = rsm(sf36[,c(13, 14, 15, 16)],sf36=TRUE)
  dat$sf36_BP_pain = rsm(sf36[,c(21, 22)],sf36=TRUE)
  dat$sf36_GH_general = rsm(sf36[,c(1, 33, 34, 35, 36)],sf36=TRUE)
  dat$sf36_VT_vitality = rsm(sf36[,c(23, 27, 29, 31)],sf36=TRUE)
  dat$sf36_SF_social = rsm(sf36[,c(20, 32)],sf36=TRUE)
  dat$sf36_RE_role_emotional = rsm(sf36[,c(17, 18, 19)],sf36=TRUE)
  dat$sf36_MH_mental_health = rsm(sf36[,c(24, 25, 26, 28, 30)],sf36=TRUE)
  subdat = as.matrix(dat[,grep("sf36",colnames(dat))])
  # Rescale to Z-scores according to British/American data
  s_ord=gsub("sf36_","",colnames(subdat)) # Names of columns without 'sf36_'
  sf36_z=t((t(subdat) - sf36_dist[s_ord,]$mean)/sf36_dist[s_ord,]$sd)
  # Generate PCS and MCS scores
  if (sf36_use_z) sc=c(1,0) else sc=c(10,50)
  dat$sf36_pcs = (sf36_z %*% sf36_dist[s_ord,]$PCS_factor)*sc[1] + sc[2]
  dat$sf36_mcs = (sf36_z %*% sf36_dist[s_ord,]$MCS_factor)*sc[1] + sc[2]

  ## EQ5D scores not to be used directly
  
  ## ICECAP
  icecap = dat0[,grep("icecap_",colnames(dat0))]
  dat$icecap_total = rsm(icecap[,1:5])
  
  ## Hallucination modalities
  modalities = dat0[,grep("modality_",colnames(dat0))]
  dat$modality_total=rsm(modalities)
  dat$modality_total_excl_felt_presence = rsm(modalities[,1:4])
  
  # Save summary table
  muse_summary[[i]]=dat

}

# Correct site discrepancy
for (i in 1:length(muse_summary[[1]]$id)) {
  idx=muse_summary[[1]]$id[i]
  sx=muse_summary[[1]]$site[i]
  w2=which(muse_summary[[2]]$id==idx)
  w3=which(muse_summary[[3]]$id==idx)
  muse_summary[[2]]$site[i]=sx
  muse_summary[[3]]$site[i]=sx
}


## Specify other (non-PPO) outcomes
other_outcomes=c("psyrats_hdis",
                 "hpsvq_total","hpsvq_negative",
                 "dass21_total",
                 "qpr_total",
                 "choice_short_total",
                 "sf36_pcs",
                 "sf36_mcs")



cat("Completed initial data processing\n\n")



##*****************************************##
## Checks and summaries                  ####
##*****************************************##

cat("General data summary\n\n")

cat(paste0("Total number of participants in data: ",
           length(unique(muse_summary[[1]]$id)),"\n"))
cat(paste0("Total number of participants in treatment group 1: ",
           length(unique(muse_summary[[1]]$id[which(muse_summary[[1]]$group==1)])),"\n"))
cat(paste0("Total number of participants in treatment group 2: ",
           length(unique(muse_summary[[1]]$id[which(muse_summary[[1]]$group==2)])),"\n"))
cat("\n")
cat(paste0("Total number of participants at site 1: ",
           length(unique(muse_summary[[1]]$id[which(muse_summary[[1]]$site==1)])),"\n"))
cat(paste0("Total number of participants at site 2: ",
           length(unique(muse_summary[[1]]$id[which(muse_summary[[1]]$site==2)])),"\n"))
cat("\n")
cat(paste0("Total number of participants with PSYRATS-voices total data at baseline: ",
           length(which(is.finite(muse_summary[[1]]$psyrats_voices_total))),"\n"))
cat(paste0("Total number of participants with PSYRATS-voices total data at 8 weeks: ",
           length(which(is.finite(muse_summary[[2]]$psyrats_voices_total))),"\n"))
cat(paste0("Total number of participants with PSYRATS-voices total data at 12 weeks: ",
           length(which(is.finite(muse_summary[[3]]$psyrats_voices_total))),"\n"))
cat("\n")

# Table: tabulate mean,median etc across these categories
all_id=muse_summary[[1]]$id
cats=list(
  all=all_id,
  group1=all_id[which(muse_summary[[1]]$group==1)],
  group2=all_id[which(muse_summary[[1]]$group==2)],
  site1_all=all_id[which(muse_summary[[1]]$site==1)],
  site1_group1=all_id[which((muse_summary[[1]]$site==1) & (muse_summary[[1]]$group==1))],
  site1_group2=all_id[which((muse_summary[[1]]$site==1) & (muse_summary[[1]]$group==2))],
  site2_all=all_id[which(muse_summary[[1]]$site==2)],
  site2_group1=all_id[which((muse_summary[[1]]$site==2) & (muse_summary[[1]]$group==1))],
  site2_group2=all_id[which((muse_summary[[1]]$site==2) & (muse_summary[[1]]$group==2))]
)

tab_cols=setdiff(colnames(muse_summary[[1]]),c("site","id","group"))
tab_format=rep("real",length(tab_cols))
tab_format[grep("modality",tab_cols)]="count"
muse_table=c()
for (i in 1:length(tab_cols)) {
  for (t in 1:3) {
    mtab=muse_summary[[t]]
    mid=mtab$id
    xcol=c()
    for (g in 1:length(cats)) {
      xid=match(cats[[g]],mid)
      summ=muse_format(mtab[xid,tab_cols[i]],type=tab_format[i],dig=ndig)
      xcol=c(xcol,summ)
    }
    muse_table=rbind(muse_table,xcol)
  }
}
muse_table=cbind(rep(tab_format,each=3),muse_table)
colnames(muse_table)=c("variable_type",names(cats))
rownames(muse_table)=as.vector(outer(c("baseline_","8week_","12week_"),tab_cols,paste0))

muse_summary_table=muse_table[
  c(grep("psyrats_total",rownames(muse_table)),
    grep("psyrats_voices_total",rownames(muse_table)),
    grep("psyrats_delusions_total",rownames(muse_table))),
  ]

cat(paste0("Table of summary values across groups; format `mean (SD) m. missing%`: ","\n\n"))
print(muse_summary_table,quote=FALSE)

cat("\n")
tfile="./Analysis/Results/general_table.csv"
write.csv(muse_table,file=tfile,quote=FALSE)
cat(paste0("Full table saved in: ",tfile))
cat("\n\n\n")



##*****************************************##
## Mixed linear model analysis - PPO     ####
##*****************************************##

## Put together data frame for main analysis

# Matching indices for IDs, in case IDs not in order
m2=match(muse_summary[[1]]$id,muse_summary[[2]]$id)
m3=match(muse_summary[[1]]$id,muse_summary[[3]]$id)

# Collect data in one data frame
muse_ppo=data.frame(
  # Individual ID
  id=c(muse_summary[[1]]$id,
       muse_summary[[2]]$id,
       muse_summary[[3]]$id),
  
  # Time (1,2, or 3, corresponding to baseline, 8 weeks, 12 weeks respectively)
  time=as.factor(c(rep(1,dim(muse_summary[[1]])[1]),
                   rep(2,dim(muse_summary[[2]])[1]),
                   rep(3,dim(muse_summary[[3]])[1]))),
  
  # Site
  site=c(muse_summary[[1]]$site,
         muse_summary[[2]]$site,
         muse_summary[[3]]$site),

  # Group (only recorded in muse_summary[[1]])
  group=c(muse_summary[[1]]$group,
          muse_summary[[1]]$group[m2],
          muse_summary[[1]]$group[m3]),
  
  # Pseudo-primary outcome (PSYRATS total score)
  psyrats_voices_total=c(muse_summary[[1]]$psyrats_voices_total,
                  muse_summary[[2]]$psyrats_voices_total,
                  muse_summary[[3]]$psyrats_voices_total)
)
# Time columns
muse_ppo$time2 = as.numeric(muse_ppo$time==2) # Time 8 weeks
muse_ppo$time3 = as.numeric(muse_ppo$time==3) # Time 12 weeks

# Fit model
muse_ppo_lme=lmer(psyrats_voices_total ~ 
                    time2 + 
                    time3 + 
                    group:time2 + 
                    group:time3 + 
                    factor(site) + 
                    (1|id),
                  data=muse_ppo)

# Point estimates of fixed and random effects
muse_ppo_fixed = summary(muse_ppo_lme)$coefficients
muse_ppo_random = as.data.frame(VarCorr(muse_ppo_lme))


# Confidence intervals
muse_ppo_ci = suppressMessages(confint(muse_ppo_lme))

# Summary table
muse_est=c(muse_ppo_random[c(which(muse_ppo_random$grp=="id"),
                             which(muse_ppo_random$grp=="Residual")),5],
           muse_ppo_fixed[c("(Intercept)", 
                            "time2", 
                            "time3", 
                            "factor(site)2", 
                            "time2:group", 
                            "time3:group"),"Estimate"])
muse_name=c("σr","σe","β0","βa2","βa3","β","β2","β3")
muse_description=c("SD of per-indivudal random effect",
                   "SD of residuals",
                   "Overall mean",
                   "Fixed effect for 8-week time point",
                   "Fixed effect for 12-week time point",
                   "Fixed effect for site",
                   "Fixed effect for 8-week time point group 2",
                   "Fixed effect for 12-week time point group 2")
out_tab=data.frame(signif(muse_est,digits=ndig),signif(muse_ppo_ci,digits=ndig),muse_description)
colnames(out_tab)=c("Estimate","CI95_lower","CI95_upper","Description")
rownames(out_tab)=muse_name


# Report
cat(paste0("Estimated beta_2 (mean effect of treatment on PSYRATS voices total score at 8 weeks) ",
           "taking group 2 as treated: ",
           signif(muse_ppo_fixed[4,1],digits=ndig)," points; ",
           " 95% CI: (",signif(muse_ppo_ci[6,1],digits=ndig),", ",
           signif(muse_ppo_ci[6,2],digits=ndig),") points"))
cat("\n\n")

cat(paste0("All parameter estimates and 95% CIs: ","\n\n"))
print(out_tab)
cat("\n\n")

ofile="./Analysis/Results/parameter_table.csv"
write.csv(out_tab,file=ofile,quote=FALSE)
cat(paste0("Parameter table saved to: ",ofile))
cat("\n\n\n")


##*****************************************##
## Sample size calculation (empirical)   ####
##*****************************************##

b2=signif(muse_ppo_fixed[5,1],digits=3)
power_file=paste0("./Analysis/Results/power_b2_",b2,"_simulation.RData")
if (redo_power_calculation==TRUE | (!file.exists(power_file))) {
  
  # Collect empirical parameter estimates
  muse_power_par=c(beta_0=muse_ppo_fixed[1,1],
                   beta_a1=0,
                   beta_a2=muse_ppo_fixed["time2",1],
                   beta_a3=muse_ppo_fixed["time3",1],
                   beta_2=muse_ppo_fixed["time2:group",1],
                   beta_3=muse_ppo_fixed["time3:group",1],
                   beta=muse_ppo_fixed["factor(site)2",1],
                   sigma_r=muse_ppo_random[1,5],
                   sigma_e=muse_ppo_random[2,5])
  
  # Simulate
  cat(paste0("Sample size calculation\n\n"))
  set.seed(39283)
  
  # Short auxiliary function to check power at particular size
  pcheck=function(size) {
    tot=rep(0,npower)
    for (j in 1:npower) tot[j]=suppressMessages(
      suppressWarnings(
        infer_b2(ngen(size,par=muse_power_par))))
    cat(paste0("Computed power at sample size: ",size,"\n"))
    return(length(which(tot<alpha))/npower)
  }
  
  # Exponentially increase sample size until power>0.99
  sizes=5 
  power=pcheck(sizes[1])
  while(max(power)<0.99) {
    nsize=round(1.5*max(sizes))
    xpower=pcheck(nsize)
    sizes=c(sizes,nsize)
    power=c(power,xpower)
  }
  
  # We now have sample sizes at which power>0.99; now find maximum size for which power<0.2
  lsize=max(sizes[which(power<0.2)])
  
  # Now find minimum sample size at which power>1-beta.
  sseq=round(seq(lsize,max(sizes),length=10))
  pseq=rep(0,length(sseq))
  for (i in 1:length(sseq)) pseq[i]=suppressWarnings(pcheck(sseq[i]))
  sizes=c(sizes,sseq)
  power=c(power,pseq)
  
  # Sort
  os=order(sizes)
  sizes=sizes[os]
  power=power[os]
  
  save(muse_power_par,sizes,power,file=power_file)
  
} else load(power_file)

# Approximate sample size
ssize=suppressWarnings(approx(power,sizes,xout=1-beta)$y)

# Report
if (is.finite(ssize)) {
  
cat(paste0("To have ",round(100*(1-beta)),"% power to detect an effect of MUSE of ",
           signif(muse_power_par["beta_2"],digits=ndig)," points on PSYRATS-voices total, ",
           "with other parameters as estimated, ",
           "we need a minimum of ",round (ssize), " samples per arm"))
  cat("\n\n\n")
} else {
  cat(paste0("With ",round(100*(1-beta)),"% power, we are unable to detect an effect of MUSE of ",
             signif(muse_power_par["beta_2"],digits=ndig)," points on PSYRATS-voices total ",
             "with ",max(sizes), " samples per arm with other parameters as estimated"))
  cat("\n\n\n")
}



##*****************************************##
## Analysis of other outcomes, no covs   ####
##*****************************************##

## Most of data frame will remain the same as for analysis of PPO

for (o in 1:length(other_outcomes)) {
  
  # Specify outcome
  outcome=other_outcomes[o]
  
  # Matching indices for IDs, in case IDs not in order
  m2=match(muse_summary[[1]]$id,muse_summary[[2]]$id)
  m3=match(muse_summary[[1]]$id,muse_summary[[3]]$id)
  
  # Collect data in one data frame
  muse_outcome=data.frame(
    # Individual ID
    id=c(muse_summary[[1]]$id,
         muse_summary[[2]]$id,
         muse_summary[[3]]$id),
    
    # Time (1,2, or 3, corresponding to baseline, 8 weeks, 12 weeks respectively)
    time=as.factor(c(rep(1,dim(muse_summary[[1]])[1]),
                     rep(2,dim(muse_summary[[2]])[1]),
                     rep(3,dim(muse_summary[[3]])[1]))),
    
    # Site
    site=c(muse_summary[[1]]$site,
           muse_summary[[2]]$site,
           muse_summary[[3]]$site),
    
    # Group (only recorded in muse_summary[[1]])
    group=c(muse_summary[[1]]$group,
            muse_summary[[1]]$group[m2],
            muse_summary[[1]]$group[m3]),
    
    # Pseudo-primary outcome (PSYRATS voices total score)
    Y=c(muse_summary[[1]][[outcome]],
        muse_summary[[2]][[outcome]],
        muse_summary[[3]][[outcome]])
  )
  # Time columns
  muse_outcome$time2 = as.numeric(muse_ppo$time==2) # Time 8 weeks
  muse_outcome$time3 = as.numeric(muse_ppo$time==3) # Time 12 weeks
  
  # Fit model
  muse_outcome_lme=lmer(Y ~ 
                          time2 + 
                          time3 + 
                          group:time2 + 
                          group:time3 + 
                          factor(site) + 
                          (1|id),
                        data=muse_outcome)
  
  # Point estimates of fixed and random effects
  muse_outcome_fixed = summary(muse_outcome_lme)$coefficients
  muse_outcome_random = as.data.frame(VarCorr(muse_outcome_lme))
  
  
  # Confidence intervals
  muse_outcome_ci = suppressMessages(confint(muse_outcome_lme))
  
  # Summary table
  muse_est=c(muse_outcome_random[c(which(muse_outcome_random$grp=="id"),
                               which(muse_outcome_random$grp=="Residual")),5],
             muse_outcome_fixed[c("(Intercept)", 
                              "time2", 
                              "time3", 
                              "factor(site)2", 
                              "time2:group", 
                              "time3:group"),"Estimate"])
  out_tab=data.frame(signif(muse_est,digits=ndig),signif(muse_outcome_ci,digits=ndig),muse_description)
  colnames(out_tab)=c("Estimate","CI95_lower","CI95_upper","Description")
  rownames(out_tab)=muse_name
  
  
  # Report
  
  cat(paste0("**** Analysis for outcome: ",outcome," ****"))
  cat("\n\n")
  
  cat(paste0("Estimated beta_2 (mean effect of treatment on outcome ",outcome," at 8 weeks) ",
             "taking group 2 as treated: ",
             signif(muse_outcome_fixed[4,1],digits=ndig)," points; ",
             " 95% CI: (",signif(muse_outcome_ci[6,1],digits=ndig),", ",
             signif(muse_outcome_ci[6,2],digits=ndig),") points"))
  cat("\n\n")
  
  cat(paste0("All parameter estimates and 95% CIs: ","\n\n"))
  print(out_tab)
  cat("\n")
  
  ofile=paste0("./Analysis/Results/parameter_table_",outcome,".csv")
  write.csv(out_tab,file=ofile,quote=FALSE)
  cat(paste0("Parameter table saved to: ",ofile))
  
  cat("\n\n")
  cat(paste0("*********************"))
  cat("\n\n")
  
}




##*****************************************##
## Check confidence interval cover       ####
##*****************************************##


cat("\n\n\n")
cat(paste0("Checking empirical cover of confidence intervals"))
cat("\n\n")

size=50 # Simulate for this many samples per group
ncheck=2000 # Simulate this many times


conf_int_file=paste0("./Analysis/Results/conf_int_cover_simulation.RData")
if (recheck_conf_int | (!file.exists(conf_int_file))) {
  
  set.seed(38729)
  
  
  # Parameters for simulation; correspond to design in SAP
  beta_0=2;
  beta_a1=0
  beta_a2=2.5
  beta_a3=-0.5
  beta_2=3
  beta_3=1
  beta=-1
  sigma_r=2
  sigma_e=1
  
  
  # Parameters in order returned by confint()
  par_check=c(sigma_r,sigma_e,beta_0,beta_a2,beta_a3,beta_2,beta_3,beta)
  names(par_check)=c("sigma_r","sigma_e","beta_0","beta_a2","beta_a3","beta_2","beta_3","beta")
  
  
  cat(paste0("Computing empirical confidence intervals for study size ",size," per group"))
  cat("\n\n")
  
  rec=matrix(0,8,ncheck)
  
  for (i in 1:ncheck) {
    dat=ngen(size,par=c(beta_0,beta_a1,beta_a2,beta_a3,beta_2,beta_3,beta,sigma_r,sigma_e))
    m1=lmer(Y~time + treat_time2 + treat_time3 + site + (1|id),data=dat)
    c1=suppressMessages(confint(m1))
    rec[,i]=(c1[,1]<par_check & c1[,2]>par_check)
    if ((i%%100)==0) cat(paste0("Completed ",i," of ",ncheck,"\n"))
  }
  
save(rec,par_check,file=conf_int_file)
  
} else load(conf_int_file)
  
cat("\n\n")
  
coverage=rowMeans(rec) # Empirical cover of each confidence interval
p_cover=pbinom(coverage*ncheck,ncheck,1-alpha) 

out=data.frame(cover=coverage,quantile=p_cover); rownames(out)=names(par_check)

cat(paste0("Confidence interval cover (nominally 95%) and quantile in Bin(n,0.95):","\n\n"))

prmatrix(out)





##*****************************************##
## Clean up                              ####
##*****************************************##

if (!is.null(text_dir)) sink()
